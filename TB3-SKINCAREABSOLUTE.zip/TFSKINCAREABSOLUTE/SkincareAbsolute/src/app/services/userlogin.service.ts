import { UserLogin } from './../models/userlogin';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserloginService {

  constructor(private http:HttpClient) { }

  addComents(login:UserLogin){
    return this.http.post<UserLogin>("http://localhost:3000/userlogin",login)
  }
}
