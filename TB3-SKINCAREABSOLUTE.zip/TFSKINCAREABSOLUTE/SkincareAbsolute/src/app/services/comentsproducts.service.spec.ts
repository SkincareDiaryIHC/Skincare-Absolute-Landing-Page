import { TestBed } from '@angular/core/testing';

import { ComentsproductsService } from './comentsproducts.service';

describe('ComentsproductsService', () => {
  let service: ComentsproductsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ComentsproductsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
