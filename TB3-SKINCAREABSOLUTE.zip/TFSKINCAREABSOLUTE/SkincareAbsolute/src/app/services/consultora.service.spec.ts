import { TestBed } from '@angular/core/testing';

import { ConsultoraService } from './consultora.service';

describe('ConsultoraService', () => {
  let service: ConsultoraService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConsultoraService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
