export interface ComentProduct{
    id:number,
    usuario:string,
    valoracion:number,
    comentario:string
}