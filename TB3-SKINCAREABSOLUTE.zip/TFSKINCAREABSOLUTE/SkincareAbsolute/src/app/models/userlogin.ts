export interface UserLogin{
    id:number,
    email:string,
    password:string
}