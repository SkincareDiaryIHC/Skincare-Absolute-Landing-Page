import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { InicioComponent } from './components/inicio/inicio.component';
import { LoginComponent } from './components/login/login.component';
import { ProductosComponent } from './components/productos/productos.component';
import { ConsultorasComponent } from './components/consultoras/consultoras.component';
import { AngularMaterialModule } from './components/shared/angular-material/angular-material.module';
import { InfoproductsComponent } from './components/product-detail/infoproducts/infoproducts.component';
import { Infoproducts2Component } from './components/product-detail/infoproducts2/infoproducts2.component';
import { Infoproducts3Component } from './components/product-detail/infoproducts3/infoproducts3.component';
import { Infoproducts4Component } from './components/product-detail/infoproducts4/infoproducts4.component';
import { Infoproducts5Component } from './components/product-detail/infoproducts5/infoproducts5.component';
import { Infoproducts6Component } from './components/product-detail/infoproducts6/infoproducts6.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddCommentproductComponent } from './components/add-commentproduct/add-commentproduct.component';
import { HttpClientModule } from '@angular/common/http';
import { InfoconsultoraComponent } from './components/consultora-detail/infoconsultora/infoconsultora.component';
import { Infoconsultora2Component } from './components/consultora-detail/infoconsultora2/infoconsultora2.component';
import { Infoconsultora3Component } from './components/consultora-detail/infoconsultora3/infoconsultora3.component';
import { Infoconsultora4Component } from './components/consultora-detail/infoconsultora4/infoconsultora4.component';
import { Infoconsultora5Component } from './components/consultora-detail/infoconsultora5/infoconsultora5.component';
import { Infoconsultora6Component } from './components/consultora-detail/infoconsultora6/infoconsultora6.component';
import { AddCommentconsultoraComponent } from './components/add-commentconsultora/add-commentconsultora.component';
import { PortadaLoginComponent } from './components/portada-login/portada-login.component';
import { RegistroClienteComponent } from './components/registro-cliente/registro-cliente.component';
import { RegistroConsultoraComponent } from './components/registro-consultora/registro-consultora.component';
import { CarritoComponent } from './components/carrito/carrito.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    InicioComponent,
    LoginComponent,
    ProductosComponent,
    ConsultorasComponent,
    InfoproductsComponent,
    Infoproducts2Component,
    Infoproducts3Component,
    Infoproducts4Component,
    Infoproducts5Component,
    Infoproducts6Component,
    AddCommentproductComponent,
    InfoconsultoraComponent,
    Infoconsultora2Component,
    Infoconsultora3Component,
    Infoconsultora4Component,
    Infoconsultora5Component,
    Infoconsultora6Component,
    AddCommentconsultoraComponent,
    PortadaLoginComponent,
    RegistroClienteComponent,
    RegistroConsultoraComponent,
    CarritoComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularMaterialModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
