import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infoproducts6',
  templateUrl: './infoproducts6.component.html',
  styleUrls: ['./infoproducts6.component.css']
})
export class Infoproducts6Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
