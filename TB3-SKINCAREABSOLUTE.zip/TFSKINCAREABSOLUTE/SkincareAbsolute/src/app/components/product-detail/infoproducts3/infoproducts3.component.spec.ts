import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Infoproducts3Component } from './infoproducts3.component';

describe('Infoproducts3Component', () => {
  let component: Infoproducts3Component;
  let fixture: ComponentFixture<Infoproducts3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Infoproducts3Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Infoproducts3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
