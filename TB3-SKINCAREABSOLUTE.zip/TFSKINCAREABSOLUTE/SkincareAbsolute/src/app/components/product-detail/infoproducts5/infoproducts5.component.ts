import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infoproducts5',
  templateUrl: './infoproducts5.component.html',
  styleUrls: ['./infoproducts5.component.css']
})
export class Infoproducts5Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
