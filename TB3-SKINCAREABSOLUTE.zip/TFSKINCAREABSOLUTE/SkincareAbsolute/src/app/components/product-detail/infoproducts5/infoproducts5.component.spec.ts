import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Infoproducts5Component } from './infoproducts5.component';

describe('Infoproducts5Component', () => {
  let component: Infoproducts5Component;
  let fixture: ComponentFixture<Infoproducts5Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Infoproducts5Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Infoproducts5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
