import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infoproducts2',
  templateUrl: './infoproducts2.component.html',
  styleUrls: ['./infoproducts2.component.css']
})
export class Infoproducts2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
