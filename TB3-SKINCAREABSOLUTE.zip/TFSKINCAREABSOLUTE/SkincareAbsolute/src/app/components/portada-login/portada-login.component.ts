import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portada-login',
  templateUrl: './portada-login.component.html',
  styleUrls: ['./portada-login.component.css']
})
export class PortadaLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
