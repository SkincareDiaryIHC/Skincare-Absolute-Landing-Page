import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PortadaLoginComponent } from './portada-login.component';

describe('PortadaLoginComponent', () => {
  let component: PortadaLoginComponent;
  let fixture: ComponentFixture<PortadaLoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PortadaLoginComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PortadaLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
