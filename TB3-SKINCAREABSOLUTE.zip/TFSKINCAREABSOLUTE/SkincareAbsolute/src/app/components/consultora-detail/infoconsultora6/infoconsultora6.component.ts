import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infoconsultora6',
  templateUrl: './infoconsultora6.component.html',
  styleUrls: ['./infoconsultora6.component.css']
})
export class Infoconsultora6Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
