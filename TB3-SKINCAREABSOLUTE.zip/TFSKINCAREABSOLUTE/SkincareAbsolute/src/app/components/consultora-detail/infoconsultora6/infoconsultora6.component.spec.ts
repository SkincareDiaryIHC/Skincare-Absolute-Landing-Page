import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Infoconsultora6Component } from './infoconsultora6.component';

describe('Infoconsultora6Component', () => {
  let component: Infoconsultora6Component;
  let fixture: ComponentFixture<Infoconsultora6Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Infoconsultora6Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Infoconsultora6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
