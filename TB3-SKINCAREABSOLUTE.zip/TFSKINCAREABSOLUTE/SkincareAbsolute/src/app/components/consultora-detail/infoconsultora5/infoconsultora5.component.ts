import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infoconsultora5',
  templateUrl: './infoconsultora5.component.html',
  styleUrls: ['./infoconsultora5.component.css']
})
export class Infoconsultora5Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
