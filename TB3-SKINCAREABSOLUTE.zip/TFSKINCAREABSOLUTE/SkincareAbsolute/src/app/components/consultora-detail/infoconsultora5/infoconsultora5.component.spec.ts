import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Infoconsultora5Component } from './infoconsultora5.component';

describe('Infoconsultora5Component', () => {
  let component: Infoconsultora5Component;
  let fixture: ComponentFixture<Infoconsultora5Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Infoconsultora5Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Infoconsultora5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
