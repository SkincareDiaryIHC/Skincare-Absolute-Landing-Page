import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infoconsultora4',
  templateUrl: './infoconsultora4.component.html',
  styleUrls: ['./infoconsultora4.component.css']
})
export class Infoconsultora4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
