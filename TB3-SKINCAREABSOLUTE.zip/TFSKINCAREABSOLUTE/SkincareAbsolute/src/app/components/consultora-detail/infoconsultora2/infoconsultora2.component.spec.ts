import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Infoconsultora2Component } from './infoconsultora2.component';

describe('Infoconsultora2Component', () => {
  let component: Infoconsultora2Component;
  let fixture: ComponentFixture<Infoconsultora2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Infoconsultora2Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Infoconsultora2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
