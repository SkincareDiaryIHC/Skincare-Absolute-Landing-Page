import { Consultora } from './../../models/consultora';
import { ConsultoraService } from './../../services/consultora.service';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registro-consultora',
  templateUrl: './registro-consultora.component.html',
  styleUrls: ['./registro-consultora.component.css']
})
export class RegistroConsultoraComponent implements OnInit {
  myForm!:FormGroup;

  constructor(private formBuilder:FormBuilder, private http:HttpClient, private router:Router, private consultoraService:ConsultoraService) { }

  ngOnInit(): void {
    this.myForm = this.formBuilder.group({
      firstname:["",[Validators.required]],
      lastname:["",[Validators.required]],
      empresa:["",[Validators.required]],
      email:["",[Validators.required]],
      password:["",[Validators.required]],
    })
  }

  ConsultoraSave() {
    const consultora:Consultora= {
      id:0,
      nombre: this.myForm.get("firstname")!.value,
      apellido: this.myForm.get("lastname")!.value,
      empresa: this.myForm.get("empresa")!.value,
      email: this.myForm.get("email")!.value,
      password: this.myForm.get("password")!.value,
    }
    this.consultoraService.addConsultora(consultora).subscribe({
      next:(res)=>{
        alert("Consultora registrado exitosamente");
        this.myForm.reset();
        this.router.navigate(["/"])
      },
      error: (err) => {
        alert("Error para registro de consultora")
      }
    })
  }

}
