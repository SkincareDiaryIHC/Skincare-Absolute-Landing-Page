import { ClienteService } from './../../services/cliente.service';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Cliente } from 'src/app/models/cliente';

@Component({
  selector: 'app-registro-cliente',
  templateUrl: './registro-cliente.component.html',
  styleUrls: ['./registro-cliente.component.css']
})
export class RegistroClienteComponent implements OnInit {
  myForm!:FormGroup;

  constructor(private formBuilder:FormBuilder, private http:HttpClient, private router:Router, private clienteService:ClienteService) { }

  ngOnInit(): void {
    this.myForm = this.formBuilder.group({
      firstname:["",[Validators.required]],
      lastname:["",[Validators.required]],
      email:["",[Validators.required]],
      password:["",[Validators.required]],
    })
  }

  ClienteSave() {
    const cliente:Cliente= {
      id:0,
      nombre: this.myForm.get("firstname")!.value,
      apellido: this.myForm.get("lastname")!.value,
      email: this.myForm.get("email")!.value,
      password: this.myForm.get("password")!.value,
    }
    this.clienteService.addCliente(cliente).subscribe({
      next:(res)=>{
        alert("Cliente registrado exitosamente");
        this.myForm.reset();
        this.router.navigate(["/"])
      },
      error: (err) => {
        alert("Error para registro de cliente")
      }
    })
  }

}
