import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCommentproductComponent } from './add-commentproduct.component';

describe('AddCommentproductComponent', () => {
  let component: AddCommentproductComponent;
  let fixture: ComponentFixture<AddCommentproductComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddCommentproductComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddCommentproductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
