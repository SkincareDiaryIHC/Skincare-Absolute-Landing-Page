import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ComentsproductsService } from './../../services/comentsproducts.service';
import { ComentProduct } from './../../models/comentsproducts';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-add-commentproduct',
  templateUrl: './add-commentproduct.component.html',
  styleUrls: ['./add-commentproduct.component.css']
})
export class AddCommentproductComponent implements OnInit {

  myForm!:FormGroup;
  actionBtn:string ="Save";
  constructor(private formBuilder:FormBuilder,
              private comentsproductService:ComentsproductsService,
              private router:Router,
              @Inject(MAT_DIALOG_DATA) public editComent:any,
              private dialogRef:MatDialogRef<AddCommentproductComponent>,
              private activatedRouter: ActivatedRoute,) { }

  ngOnInit(): void {
    this.reactiveForm();

    if(this.editComent){
      this.actionBtn="Editar";
      this.myForm.controls['usuario'].setValue(this.editComent.usuario),
      this.myForm.controls['valoracion'].setValue(this.editComent.valoracion),
      this.myForm.controls['comentario'].setValue(this.editComent.comentario)
    }
  }

  reactiveForm():void {
    this.myForm = this.formBuilder.group({
      id:[""],
      usuario:["",[Validators.required]],
      valoracion:[0,[Validators.required]],
      comentario:["",[Validators.required,Validators.maxLength(200)]],
    }
    )
    }
    saveComent() {
      const comentsproducts:ComentProduct= {
        id:0,
        usuario: this.myForm.get("usuario")!.value,
        valoracion: this.myForm.get("valoracion")!.value,
        comentario: this.myForm.get("comentario")!.value,

      }

      //this.router.navigate(["/"]);

      if(!this.editComent){
        if(this.myForm.valid){
          this.comentsproductService.addComents(comentsproducts).subscribe({
            next: (data) => {
              alert("Comentario añadido con éxito")
              this.myForm.reset();
              this.dialogRef.close();
              //this.router.navigate(["/"]);
            },
            error: (err) => {
              alert("Error para añadir comentario")
            }
          }
         
          )
        }
      }
      else{
        this.updateComents()
      }

    }

    updateComents(){
      this.comentsproductService.updateComents(this.myForm.value,this.editComent.id)
      .subscribe({
        next:(res)=>{
          alert("Comentario editado con éxito");
          this.myForm.reset();
          this.dialogRef.close('update');
        },
        error: (err) => {
          alert("Error para editar comentario")
        }
      })
    }

}
