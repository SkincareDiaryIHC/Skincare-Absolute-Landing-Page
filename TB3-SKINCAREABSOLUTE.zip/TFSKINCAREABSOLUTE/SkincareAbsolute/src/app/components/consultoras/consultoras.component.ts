import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consultoras',
  templateUrl: './consultoras.component.html',
  styleUrls: ['./consultoras.component.css']
})
export class ConsultorasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
