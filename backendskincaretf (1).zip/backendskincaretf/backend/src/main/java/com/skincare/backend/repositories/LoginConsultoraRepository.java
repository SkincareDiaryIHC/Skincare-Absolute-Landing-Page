package com.skincare.backend.repositories;

import com.skincare.backend.entities.LoginConsultora;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoginConsultoraRepository extends JpaRepository<LoginConsultora,Long> {

}
