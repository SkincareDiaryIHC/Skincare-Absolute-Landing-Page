package com.skincare.backend.entities;


import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "loginconsultora")
@NoArgsConstructor
@Data
public class LoginConsultora {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    private String email;
    private String password;

    @OneToMany(mappedBy = "loginConsultora")
    private List<Consultora> consultoras;


    public LoginConsultora(String email, String password) {
        this.email = email;
        this.password = password;
    }
}
