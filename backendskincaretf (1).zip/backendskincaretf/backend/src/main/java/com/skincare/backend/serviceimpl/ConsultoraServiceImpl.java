package com.skincare.backend.serviceimpl;

import com.skincare.backend.entities.Consultora;
import com.skincare.backend.entities.Product;
import com.skincare.backend.repositories.ConsultoraRepository;
import com.skincare.backend.services.ConsultoraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

public class ConsultoraServiceImpl implements ConsultoraService {
    @Autowired
    private ConsultoraRepository consultoraRepository;

    public List<Consultora> ListAll(){
        List<Consultora> consultoras;
        consultoras=consultoraRepository.findAll();
        for (Consultora consul: consultoras) {
            consul.setComentConsultoras(null);
            consul.setLoginConsultora(null);
        }
        return consultoras;
    }
}
