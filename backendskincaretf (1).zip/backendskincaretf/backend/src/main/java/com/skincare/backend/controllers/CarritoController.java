package com.skincare.backend.controllers;

import com.skincare.backend.entities.Carrito;
import com.skincare.backend.repositories.CarritoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CarritoController {
    @Autowired
    private CarritoRepository carritoRepository;

    @GetMapping("/carritos")
    public ResponseEntity<List<Carrito>> getAllCarrito(){
        List<Carrito> carritos;
        carritos=carritoRepository.findAll();
        if (carritos.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        for (Carrito carr: carritos) {
            carr.setCliente(null);
            carr.setProducts(null);
        }
        return new ResponseEntity<List<Carrito>>(carritos, HttpStatus.OK);
    }

    @GetMapping("/carritos/{id}")
    public ResponseEntity<Carrito> getCarritoById(@PathVariable("id") Long id){
        Carrito carrito=carritoRepository.findById(id).get();
        carrito.setCliente(null);
        carrito.setProducts(null);
        return new ResponseEntity<Carrito>(carrito,HttpStatus.OK);
    }

    @PostMapping("/carritos")
    public ResponseEntity<Carrito> createCarrito(@RequestBody Carrito carrito) {
        Carrito newCarrito =  carritoRepository.save(new Carrito(carrito.getCantidad(),carrito.getPrecioTotal()));
        return new ResponseEntity<Carrito>(newCarrito,HttpStatus.CREATED);
    }

    @DeleteMapping("/carritos/{id}")
    public ResponseEntity<HttpStatus> deleteCarritoById(@PathVariable("id") Long id) {
        carritoRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/carritos/{id}")
    public ResponseEntity<Carrito> updateCarritoById(@PathVariable("id") Long id, @RequestBody Carrito carrito)
    {

        Carrito foundCarrito =  carritoRepository.findById(id).get();

        if (carrito.getCantidad()!=null)
            foundCarrito.setCantidad(carrito.getCantidad());
        if (carrito.getPrecioTotal()!=null)
            foundCarrito.setPrecioTotal(carrito.getPrecioTotal());

        Carrito updateCarrito =carritoRepository.save(foundCarrito);
        updateCarrito.setCliente(null);
        updateCarrito.setProducts(null);
        return new ResponseEntity<Carrito>(updateCarrito,HttpStatus.OK);
    }
}
