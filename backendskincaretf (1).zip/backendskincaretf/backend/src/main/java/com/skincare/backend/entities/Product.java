package com.skincare.backend.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "products")
@Data
@NoArgsConstructor
public class Product {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private String informacion;
    private String guia_aplicacion;
    private String marca;
    private String precio;
    private String tipo_piel;
    private String image;

    @OneToMany(mappedBy = "product")
    private List<ComentProduct> comentProducts;

    @ManyToMany
    @JoinTable(
            name = "products_carritos",
            joinColumns = {
                    @JoinColumn(
                            name = "product_id",
                            referencedColumnName = "id",
                            nullable = false
                    )
            },
            inverseJoinColumns = {
                    @JoinColumn (
                            name = "carrito_id",
                            referencedColumnName = "id",
                            nullable = false
                    )
            }
    )

    private List<Carrito> carritos;

    public Product(String nombre, String informacion, String guia_aplicacion, String marca, String precio, String tipo_piel, String image) {
        this.nombre = nombre;
        this.informacion = informacion;
        this.guia_aplicacion = guia_aplicacion;
        this.marca = marca;
        this.precio = precio;
        this.tipo_piel = tipo_piel;
        this.image = image;
    }
}
