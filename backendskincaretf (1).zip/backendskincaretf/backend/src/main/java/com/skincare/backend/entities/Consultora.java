package com.skincare.backend.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "consultoras")
@Data
@NoArgsConstructor
public class Consultora {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private String apellido;
    private String descripcion;
    private String empresa;
    private String contacto;
    private String celular;

    private String image;

    @ManyToOne
    @JoinColumn(name="login_id")
    private LoginConsultora loginConsultora;

    @OneToMany(mappedBy = "consultora")
    private List<ComentConsultora> comentConsultoras;

    public Consultora(String nombre, String apellido, String descripcion, String empresa, String contacto, String celular,String image,LoginConsultora loginConsultora) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.descripcion = descripcion;
        this.empresa = empresa;
        this.contacto = contacto;
        this.celular = celular;
        this.image=image;
        this.loginConsultora=loginConsultora;
    }
}
