package com.skincare.backend.services;

import com.skincare.backend.entities.Consultora;

import java.util.List;

public interface ConsultoraService {
    public List<Consultora> ListAll();
}
