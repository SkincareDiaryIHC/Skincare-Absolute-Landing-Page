package com.skincare.backend.repositories;

import com.skincare.backend.entities.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product,Long> {
    Product findByMarca(String marca);
}
