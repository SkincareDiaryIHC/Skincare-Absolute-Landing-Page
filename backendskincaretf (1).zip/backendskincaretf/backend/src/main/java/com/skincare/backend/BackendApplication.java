package com.skincare.backend;

import com.skincare.backend.entities.*;
import com.skincare.backend.repositories.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.List;

@SpringBootApplication
public class BackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendApplication.class, args);
	}
	@Bean
	public CommandLineRunner mappingDemo(
			LoginRepository loginRepository,
			ClienteRepository clienteRepository,
			LoginConsultoraRepository loginConsultoraRepository,
			ConsultoraRepository consultoraRepository,
			ComentConsultoraRepository comentConsultoraRepository,
			ProductRepository productRepository,
			ComentProductRepository comentProductRepository

	){
		return args -> {
			Login login1=new Login("moragutie@gmail.com","73737$yeueue");
			loginRepository.save(login1);
			Login login2=new Login("floremari@gmail.com","838374494");
			loginRepository.save(login2);
			Login login3=new Login("jerimarth@gmail.com","mie73648029");
			loginRepository.save(login3);

			clienteRepository.save(new Cliente("Fernanda", "Morales Gutierrez", "Piel Grasa", "Estudiante universitaria",login1));
			clienteRepository.save(new Cliente("Maria", "Flores Velarde", "Piel Seca", "Ama de casa",login2));
			clienteRepository.save(new Cliente("Martha", "Jerí Ramirez", "Piel Grasa", "Mujer de negocios",login3));

			LoginConsultora loginConsultora1=new LoginConsultora("moragutie@gmail.com","73737$yeueue");
			loginConsultoraRepository.save(loginConsultora1);

			//consultoraRepository.save(new Consultora("Samantha", "Juarez Meneses", "Consultora desde 2016 ", " Mary Kate","juameneses@sammy", "9838383",loginConsultora1));
			Consultora consultora1=new Consultora("Samantha", "Juarez Meneses", "Consultora desde 2016 ", " Mary Kate","juameneses@sammy", "9838383","https://img.freepik.com/foto-gratis/retrato-hermoso-mujer-joven-posicion-pared-gris_231208-10760.jpg",loginConsultora1);
			consultoraRepository.save(consultora1);

			comentConsultoraRepository.save(new ComentConsultora("2.3","recomienda buenos productos",consultora1));

			Product product = new Product("Sensibio Gel Moussant - 200 ml", "Este gel micelar limpiador y calmante refuerza la hidratación natural de la piel. Este producto limpia con suavidad y elimina por completo las impurezas.", "Aplicar en toda la cara", "Bioderma", "148.00", "Piel sensible", "https://www.farmaciauniversal24h.com/parafarmacia/19746-large_default/bioderma-sensibio-gel-moussant-200-ml.jpg");
			productRepository.save(product);

			Product product2 = new Product("Mascarilla facial - 200 ml", "Mascarilla de Arcilla y Cacao Orgánico que desintoxica, limpiando profundamente los poros, extrayendo las toxinas, exfoliando ligeramente las células muertas y absorbiendo la grasa de la superficie de la piel.", "Aplicar en toda la cara", "APU FACEMASK", "54.90", "Piel grasa", "https://cdn.shopify.com/s/files/1/0903/0912/products/APUF-MAFA-MASCARILLAFACIALCACAO-200GR_500x.jpg?v=1527360471");
			productRepository.save(product2);

			Product product3 = new Product("Hydrabio Sérum - 40 ml", "Este sérum hidratante es perfecto para el rostro, debido a que ilumina y protege tu piel, ayuda a disimular las imperfecciones y suaviza de forma duradera la textura de tu piel. ", "Aplicar en toda la cara", "Bioderma", "133.00", "Piel grasa", "https://farmaciadermatologica.com.pe/wp-content/uploads/2020/12/HYDRABIO-SERUM-40ML.jpg");
			productRepository.save(product3);

			comentProductRepository.save(new ComentProduct("4.5", "Muy bueno", product));
			comentProductRepository.save(new ComentProduct("1.5", "Muy malo", product2));


/*
			Cliente cliente;
			//cliente=clienteRepository.findByTipopiel("Piel Seca");
			//System.out.println(cliente.getNombre());

			//cliente=clienteRepository.findById(Long.valueOf(2)).get();
			//System.out.println(cliente.getNombre());

			List<Cliente> clientes;
			clientes=clienteRepository.findByTipopiel("Piel Grasa");
			for (Cliente cli: clientes) {
				System.out.println(cli.getNombre());
			}


			List<Product> products;
			products=productRepository.findByMarca("Bioderma");
			for (Product pro: products) {
				System.out.println(pro.getNombre());
			}
*/

		};

	}


}
