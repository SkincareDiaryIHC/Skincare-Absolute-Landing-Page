package com.skincare.backend.controllers;


import com.skincare.backend.entities.Cliente;
import com.skincare.backend.exceptions.ResourceNotFoundException;
import com.skincare.backend.repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ClienteController {

    @Autowired
    private ClienteRepository clienteRepository;

    @GetMapping("/clientes")
    public ResponseEntity<List<Cliente>> getAllCliente(){
        List<Cliente> clientes;
        clientes=clienteRepository.findAll();
        if (clientes.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        for (Cliente cli: clientes) {
            cli.setLogin(null);
            cli.setCarritos(null);
        }
        return new ResponseEntity<List<Cliente>>(clientes, HttpStatus.OK);
    }

    @GetMapping("/clientes/logins")
    public ResponseEntity<List<Cliente>> getAllClientesAndLogins() {
        List<Cliente> clientes = clienteRepository.findAll();
        for (Cliente c : clientes) {
            c.getLogin().setClientes(null);
        }
        return new ResponseEntity<List<Cliente>>(clientes, HttpStatus.OK);
    }

    @GetMapping("/clientes/{id}")
    public ResponseEntity<Cliente> getClienteById(@PathVariable("id") Long id){
        //Cliente cliente=clienteRepository.findById(id).get();
        Cliente cliente=clienteRepository.findById(id).
                                                        orElseThrow(()->new ResourceNotFoundException("No se encontró Cliente con id="+id));
        cliente.setLogin(null);
        cliente.setCarritos(null);
        return new ResponseEntity<Cliente>(cliente,HttpStatus.OK);
    }

    @PostMapping("/clientes")
    public ResponseEntity<Cliente> createCliente(@RequestBody Cliente cliente) {
        Cliente newCliente =  clienteRepository.save(new Cliente(cliente.getNombre(),cliente.getApellido(),cliente.getTipopiel(),cliente.getDescripcion(),cliente.getLogin()));
        return new ResponseEntity<Cliente>(newCliente,HttpStatus.CREATED);
    }

    @GetMapping("/clientes/tipopiel/{tipopiel}")
    public ResponseEntity<Cliente> getClienteByTipopiel(@PathVariable("tipopiel") String tipopiel){
        Cliente cliente=clienteRepository.findByTipopielJPQL(tipopiel);
        cliente.setLogin(null);
        return new ResponseEntity<Cliente>(cliente,HttpStatus.OK);
    }

    @DeleteMapping("/clientes/{id}")
    public ResponseEntity<HttpStatus> deleteClienteById(@PathVariable("id") Long id) {
        clienteRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/clientes/{id}")
    public ResponseEntity<Cliente> updateClienteById(@PathVariable("id") Long id, @RequestBody Cliente cliente)
    {

        Cliente foundCliente =  clienteRepository.findById(id).get();

        if (cliente.getNombre()!=null)
            foundCliente.setNombre(cliente.getNombre());
        if (cliente.getApellido()!=null)
            foundCliente.setApellido(cliente.getApellido());
        if (cliente.getTipopiel()!=null)
            foundCliente.setTipopiel(cliente.getTipopiel());
        if (cliente.getDescripcion()!=null)
            foundCliente.setDescripcion(cliente.getDescripcion());

        Cliente updateCliente =clienteRepository.save(foundCliente);
        updateCliente.setLogin(null);
        updateCliente.setCarritos(null);
        return new ResponseEntity<Cliente>(updateCliente,HttpStatus.OK);
    }


}
