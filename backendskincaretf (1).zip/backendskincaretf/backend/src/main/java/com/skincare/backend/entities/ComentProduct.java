package com.skincare.backend.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "comentproductos")
@Data
@NoArgsConstructor

public class ComentProduct {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    private String valoracion;
    private String comentario;

    @ManyToOne
    @JoinColumn(name="id_producto")
    private Product product;

    public ComentProduct(String valoracion, String comentario,Product product) {
        this.valoracion = valoracion;
        this.comentario = comentario;
        this.product=product;
    }
}
