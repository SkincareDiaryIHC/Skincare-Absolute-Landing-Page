package com.skincare.backend.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "comentconsultoras")
@NoArgsConstructor
@Data
public class ComentConsultora {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    private String valoracion;
    private String comentario;

    @ManyToOne
    @JoinColumn(name="id_consultora")
    private Consultora consultora;

    public ComentConsultora(String valoracion, String comentario,Consultora consultora) {
        this.valoracion = valoracion;
        this.comentario = comentario;
        this.consultora = consultora;
    }
}
