package com.skincare.backend.repositories;

import com.skincare.backend.entities.ComentConsultora;
import com.skincare.backend.entities.Consultora;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComentConsultoraRepository extends JpaRepository<ComentConsultora,Long> {
}
