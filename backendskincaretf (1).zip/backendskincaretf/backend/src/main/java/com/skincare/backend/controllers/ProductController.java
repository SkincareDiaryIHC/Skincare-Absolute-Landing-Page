package com.skincare.backend.controllers;

import com.skincare.backend.entities.Cliente;
import com.skincare.backend.entities.Product;
import com.skincare.backend.repositories.ProductRepository;
import com.skincare.backend.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api")
public class ProductController {
    @Autowired
    private ProductService productService;

    @Autowired
    private ProductRepository productRepository;

    @GetMapping("/products")
    public ResponseEntity<List<Product>> getAllProducts(){
        List<Product> products;
        products=productRepository.findAll();
        if (products.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        for (Product pro: products) {
            pro.setComentProducts(null);
        }
        return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
    }

    @PostMapping("/products")
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        Product newProduct =  productRepository.save(new Product(product.getNombre(),product.getInformacion(),product.getGuia_aplicacion(),product.getMarca(),product.getPrecio(),product.getTipo_piel(),product.getImage()));
        return new ResponseEntity<Product>(newProduct,HttpStatus.CREATED);
    }

    @GetMapping("/products/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable("id") Long id){
        Product product=productRepository.findById(id).get();
        product.setComentProducts(null);
        return new ResponseEntity<Product>(product,HttpStatus.OK);
    }
    @GetMapping("/products/marca/{marca}")
    public ResponseEntity<Product> getProductByMarca(@PathVariable("marca") String marca){
        Product product=productRepository.findByMarca(marca);
        product.setComentProducts(null);
        return new ResponseEntity<Product>(product,HttpStatus.OK);
    }
    @PutMapping("/products/{id}")
    public ResponseEntity<Product> updateProductById(@PathVariable("id") Long id, @RequestBody Product product) {

        Product foundProduct =  productRepository.findById(id).get();

        if (product.getNombre()!=null)
            foundProduct.setNombre(product.getNombre());
        if (product.getInformacion()!=null)
            foundProduct.setInformacion(product.getInformacion());

        if (product.getGuia_aplicacion()!=null)
            foundProduct.setGuia_aplicacion(product.getGuia_aplicacion());
        if (product.getMarca()!=null)
            foundProduct.setMarca(product.getMarca());

        if (product.getPrecio()!=null)
            foundProduct.setPrecio(product.getPrecio());
        if (product.getTipo_piel()!=null)
            foundProduct.setTipo_piel(product.getTipo_piel());
        if (product.getImage()!=null)
            foundProduct.setImage(product.getImage());

        Product updateProduct =productRepository.save(foundProduct);
        updateProduct.setComentProducts(null);
        return new ResponseEntity<Product>(updateProduct,HttpStatus.OK);

    }
    @DeleteMapping("/products/{id}")
    public ResponseEntity<HttpStatus> deleteProductById(@PathVariable("id") Long id){
        productRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
