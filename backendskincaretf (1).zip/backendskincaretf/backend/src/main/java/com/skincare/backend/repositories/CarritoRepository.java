package com.skincare.backend.repositories;

import com.skincare.backend.entities.Carrito;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarritoRepository extends JpaRepository<Carrito,Long> {
}
