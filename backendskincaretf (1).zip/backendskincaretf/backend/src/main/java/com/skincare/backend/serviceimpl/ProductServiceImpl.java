package com.skincare.backend.serviceimpl;

import com.skincare.backend.entities.Product;
import com.skincare.backend.repositories.ProductRepository;
import com.skincare.backend.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductRepository productRepository;
    public List<Product> ListAll(){
        List<Product> products;
        products=productRepository.findAll();
        for (Product pro: products) {
            pro.setComentProducts(null);
        }
        return products;
    }
}
