package com.skincare.backend.repositories;

import com.skincare.backend.entities.Consultora;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsultoraRepository extends JpaRepository<Consultora,Long> {
}
