package com.skincare.backend.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "clientes")
@Data
@NoArgsConstructor
public class Cliente {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private String apellido;
    private String tipopiel;
    private String descripcion;

    @ManyToOne
    @JoinColumn(name="login_id")
    private Login login;

    @OneToMany(mappedBy = "cliente")
    private List<Carrito> carritos;
    public Cliente(String nombre, String apellido, String tipopiel, String descripcion,Login login) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.tipopiel = tipopiel;
        this.descripcion = descripcion;
        this.login=login;
    }
}
