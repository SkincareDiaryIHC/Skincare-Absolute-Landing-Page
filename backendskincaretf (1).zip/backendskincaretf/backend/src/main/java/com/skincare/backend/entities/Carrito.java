package com.skincare.backend.entities;

import ch.qos.logback.core.net.server.Client;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "carritos")
@NoArgsConstructor
@Data

public class Carrito {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;

    @ManyToMany(mappedBy = "carritos")
    private List<Product> products;

    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    private Long precioTotal;

    private Long cantidad;

    public Carrito(Long precioTotal, Long cantidad) {
        this.precioTotal = precioTotal;
        this.cantidad = cantidad;
    }
}
