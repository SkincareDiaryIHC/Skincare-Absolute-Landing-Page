package com.skincare.backend.repositories;

import com.skincare.backend.entities.ComentProduct;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComentProductRepository extends JpaRepository<ComentProduct,Long> {
}
