package com.skincare.backend.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "login")
@NoArgsConstructor
@Data
public class Login {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    private String email;
    private String password;

    @OneToMany(mappedBy = "login")
    private List<Cliente> clientes;

    public Login(String email, String password) {
        this.email = email;
        this.password = password;
    }
}
