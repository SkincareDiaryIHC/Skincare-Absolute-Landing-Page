package com.skincare.backend.services;

import com.skincare.backend.entities.Product;

import java.util.List;

public interface ProductService {
    public List<Product> ListAll();
}
