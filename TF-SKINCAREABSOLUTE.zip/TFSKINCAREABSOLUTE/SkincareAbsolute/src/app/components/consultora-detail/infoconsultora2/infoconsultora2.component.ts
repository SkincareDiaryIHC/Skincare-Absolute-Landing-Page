import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infoconsultora2',
  templateUrl: './infoconsultora2.component.html',
  styleUrls: ['./infoconsultora2.component.css']
})
export class Infoconsultora2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
