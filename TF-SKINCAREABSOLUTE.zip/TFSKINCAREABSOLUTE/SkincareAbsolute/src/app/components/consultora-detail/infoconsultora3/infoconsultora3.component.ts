import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infoconsultora3',
  templateUrl: './infoconsultora3.component.html',
  styleUrls: ['./infoconsultora3.component.css']
})
export class Infoconsultora3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
