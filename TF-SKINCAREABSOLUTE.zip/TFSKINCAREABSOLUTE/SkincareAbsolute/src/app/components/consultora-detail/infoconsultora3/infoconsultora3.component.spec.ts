import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Infoconsultora3Component } from './infoconsultora3.component';

describe('Infoconsultora3Component', () => {
  let component: Infoconsultora3Component;
  let fixture: ComponentFixture<Infoconsultora3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Infoconsultora3Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Infoconsultora3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
