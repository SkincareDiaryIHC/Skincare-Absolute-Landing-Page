import { ComentsconsultoraService } from './../../../services/comentsconsultora.service';
import { ConsultorasComponent } from './../../consultoras/consultoras.component';
import { AddCommentconsultoraComponent } from './../../add-commentconsultora/add-commentconsultora.component';
import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { ComentConsultora } from 'src/app/models/comentsconsultora';

@Component({
  selector: 'app-infoconsultora',
  templateUrl: './infoconsultora.component.html',
  styleUrls: ['./infoconsultora.component.css']
})
export class InfoconsultoraComponent implements OnInit {
  comentsconsultora:ComentConsultora[]=[];
  dataSource=new MatTableDataSource<ComentConsultora>();
  displayedColumns: string []=["id","usuario","comentario","actions"];

  openDialog() {
    this.dialog.open(AddCommentconsultoraComponent, {
      width:'30%'
    });
  }

  constructor(private dialog:MatDialog,private comentsconsultoraService:ComentsconsultoraService) { }

  ngOnInit(): void {
    this.getComentsConsultora();
  }
  getComentsConsultora(){
    this.comentsconsultoraService.getComents().subscribe(
      (data:ComentConsultora[]) => {
        this.dataSource = new MatTableDataSource(data);
      }
    );  
  }

  editComentsCosultora(element : any){
    this.dialog.open(AddCommentconsultoraComponent,{
      width:'30%',
      data:element
    })
  }

  applyFilter(event:Event){
    let filtro:string = (event.target as HTMLInputElement).value;
    this.dataSource.filter=filtro.trim().toLocaleLowerCase();
  }

  deleteComent(id: number):void {
    this.comentsconsultoraService.deleteComents(id).subscribe({
      next: (data) => {
        this.getComentsConsultora();
      }, 
      error: (err) => {
        console.log(err);
      }
    })
  }

}
