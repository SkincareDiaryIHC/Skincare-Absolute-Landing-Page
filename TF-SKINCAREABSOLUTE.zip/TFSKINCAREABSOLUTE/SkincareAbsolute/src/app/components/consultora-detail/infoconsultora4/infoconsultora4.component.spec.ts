import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Infoconsultora4Component } from './infoconsultora4.component';

describe('Infoconsultora4Component', () => {
  let component: Infoconsultora4Component;
  let fixture: ComponentFixture<Infoconsultora4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Infoconsultora4Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Infoconsultora4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
