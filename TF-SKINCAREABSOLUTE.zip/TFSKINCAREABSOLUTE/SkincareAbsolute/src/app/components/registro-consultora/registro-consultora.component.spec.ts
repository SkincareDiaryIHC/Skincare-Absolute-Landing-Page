import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistroConsultoraComponent } from './registro-consultora.component';

describe('RegistroConsultoraComponent', () => {
  let component: RegistroConsultoraComponent;
  let fixture: ComponentFixture<RegistroConsultoraComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegistroConsultoraComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RegistroConsultoraComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
