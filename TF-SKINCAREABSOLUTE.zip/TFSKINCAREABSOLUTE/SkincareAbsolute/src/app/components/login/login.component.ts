import { UserloginService } from './../../services/userlogin.service';
import { Router } from '@angular/router';
import { UserLogin } from './../../models/userlogin';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder, Validators} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  myForm!:FormGroup;

  constructor(private formBuilder:FormBuilder, private http:HttpClient, private router:Router, private userloginService:UserloginService) { }

  ngOnInit(): void {
    this.myForm = this.formBuilder.group({
      email:["",[Validators.required]],
      password:["",[Validators.required]],
    })
  }

  LoginSave() {
    const login:UserLogin= {
      id:0,
      email: this.myForm.get("email")!.value,
      password: this.myForm.get("password")!.value,
    }
    this.userloginService.addComents(login).subscribe({
      next:(res)=>{
        alert("Inicio de Sesión iniciada exitosamente");
        this.myForm.reset();
        this.router.navigate(["/"])
      },
      error: (err) => {
        alert("Error para editar comentario")
      }
    })
  }



  /*LoginSave(){
    this.http.post<any>("http://localhost:3000/userlogin",this.myForm.value)
    .subscribe(res=>{
      alert("Inicio de Sesión iniciada exitosamente");
      this.myForm.reset();
      this.route.navigate(["login"]);
    },err=>{
      alert("Fallo en el Inicio de Sesión");
    })

  }*/

}
