import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultorasComponent } from './consultoras.component';

describe('ConsultorasComponent', () => {
  let component: ConsultorasComponent;
  let fixture: ComponentFixture<ConsultorasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsultorasComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConsultorasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
