import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Infoproducts6Component } from './infoproducts6.component';

describe('Infoproducts6Component', () => {
  let component: Infoproducts6Component;
  let fixture: ComponentFixture<Infoproducts6Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Infoproducts6Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Infoproducts6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
