import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infoproducts4',
  templateUrl: './infoproducts4.component.html',
  styleUrls: ['./infoproducts4.component.css']
})
export class Infoproducts4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
