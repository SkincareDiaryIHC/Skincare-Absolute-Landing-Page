import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Infoproducts4Component } from './infoproducts4.component';

describe('Infoproducts4Component', () => {
  let component: Infoproducts4Component;
  let fixture: ComponentFixture<Infoproducts4Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Infoproducts4Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Infoproducts4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
