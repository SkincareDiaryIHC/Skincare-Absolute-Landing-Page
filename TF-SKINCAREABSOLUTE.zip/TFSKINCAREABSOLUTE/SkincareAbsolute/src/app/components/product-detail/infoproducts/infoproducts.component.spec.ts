import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InfoproductsComponent } from './infoproducts.component';

describe('InfoproductsComponent', () => {
  let component: InfoproductsComponent;
  let fixture: ComponentFixture<InfoproductsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InfoproductsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InfoproductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
