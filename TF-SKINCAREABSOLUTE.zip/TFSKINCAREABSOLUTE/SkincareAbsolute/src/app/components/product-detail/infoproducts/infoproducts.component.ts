import { AddCommentproductComponent } from './../../add-commentproduct/add-commentproduct.component';
import { ComentsproductsService } from './../../../services/comentsproducts.service';
import { Component, OnInit } from '@angular/core';
import { ComentProduct } from 'src/app/models/comentsproducts';
import { MatTableDataSource } from '@angular/material/table';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-infoproducts',
  templateUrl: './infoproducts.component.html',
  styleUrls: ['./infoproducts.component.css']
})
export class InfoproductsComponent implements OnInit {
  comentsproducts:ComentProduct[]=[];
  dataSource=new MatTableDataSource<ComentProduct>();
  displayedColumns: string []=["id","usuario","valoracion","comentario","actions"];

  openDialog() {
    this.dialog.open(AddCommentproductComponent, {
      width:'30%'
    });
  }
  //private dialog:MatDialog,

  constructor(private dialog:MatDialog,private comentsproductService:ComentsproductsService) { }

  ngOnInit(): void {
    this.getComentsProducts();
  }

  getComentsProducts():void{
    this.comentsproductService.getComents().subscribe(
      (data:ComentProduct[]) => {
        this.dataSource = new MatTableDataSource(data);
      }
    );  
  }

  editComentsProducts(element : any){
    this.dialog.open(AddCommentproductComponent,{
      width:'30%',
      data:element
    })
  }

  applyFilter(event:Event){
    let filtro:string = (event.target as HTMLInputElement).value;
    this.dataSource.filter=filtro.trim().toLocaleLowerCase();
  }

  deleteComent(id: number):void {
    this.comentsproductService.deleteComents(id).subscribe({
      next: (data) => {
        this.getComentsProducts();
      }, 
      error: (err) => {
        console.log(err);
      }
    })
  }

}
