import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infoproducts3',
  templateUrl: './infoproducts3.component.html',
  styleUrls: ['./infoproducts3.component.css']
})
export class Infoproducts3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
