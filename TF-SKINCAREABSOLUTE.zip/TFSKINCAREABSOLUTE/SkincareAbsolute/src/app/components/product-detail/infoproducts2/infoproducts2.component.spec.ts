import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Infoproducts2Component } from './infoproducts2.component';

describe('Infoproducts2Component', () => {
  let component: Infoproducts2Component;
  let fixture: ComponentFixture<Infoproducts2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Infoproducts2Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Infoproducts2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
