import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCommentconsultoraComponent } from './add-commentconsultora.component';

describe('AddCommentconsultoraComponent', () => {
  let component: AddCommentconsultoraComponent;
  let fixture: ComponentFixture<AddCommentconsultoraComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddCommentconsultoraComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddCommentconsultoraComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
