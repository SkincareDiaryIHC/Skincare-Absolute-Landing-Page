export interface Consultora{
    id:number,
    nombre:string,
    apellido:string,
    empresa:string,
    email:string,
    password:string
}