export interface ComentConsultora{
    id:number,
    usuario:string,
    comentario:string
}