import { Injectable } from '@angular/core';
import { ComentProduct } from '../models/comentsproducts';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ComentsproductsService {

  constructor(private http:HttpClient) { }

  getComents(){
    return this.http.get<ComentProduct[]>("http://localhost:3000/comentsproducts")
  }

  addComents(comentsproducts:ComentProduct){
    return this.http.post<ComentProduct>("http://localhost:3000/comentsproducts",comentsproducts)
  }

  updateComents(data:any,id:number){
    return this.http.put<any>("http://localhost:3000/comentsproducts/"+"/"+id,data);
    
  }
  deleteComents(id: number) {
    return this.http.delete("http://localhost:3000/comentsproducts/"+"/"+id.toString());
  }

}
