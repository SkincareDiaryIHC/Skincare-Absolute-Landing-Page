import { Consultora } from './../models/consultora';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ConsultoraService {

  constructor(private http:HttpClient) { }

  addConsultora(consultora:Consultora){
    return this.http.post<Consultora>("http://localhost:3000/consultora",consultora)
  }
}
