import { TestBed } from '@angular/core/testing';

import { ComentsconsultoraService } from './comentsconsultora.service';

describe('ComentsconsultoraService', () => {
  let service: ComentsconsultoraService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ComentsconsultoraService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
