import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { ComentConsultora } from '../models/comentsconsultora';

@Injectable({
  providedIn: 'root'
})
export class ComentsconsultoraService {

  constructor(private http:HttpClient) { }

  getComents(){
    return this.http.get<ComentConsultora[]>("http://localhost:3000/comentsconsultora")
  }

  addComents(comentsconsultora:ComentConsultora){
    return this.http.post<ComentConsultora>("http://localhost:3000/comentsconsultora",comentsconsultora)
  }

  updateComents(data:any,id:number){
    return this.http.put<any>("http://localhost:3000/comentsconsultora/"+"/"+id,data);
    
  }
  deleteComents(id: number) {
    return this.http.delete("http://localhost:3000/comentsconsultora/"+"/"+id.toString());
  }
}
